//
//  CTLCorePool.h
//  CTLCorePool
//
//  Created by thailinh on 1/29/19.
//  Copyright © 2019 thailinh. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for CTLCorePool.
FOUNDATION_EXPORT double CTLCorePoolVersionNumber;

//! Project version string for CTLCorePool.
FOUNDATION_EXPORT const unsigned char CTLCorePoolVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <CTLCorePool/PublicHeader.h>


